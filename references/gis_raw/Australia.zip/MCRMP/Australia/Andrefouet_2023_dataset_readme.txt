Dataset citation
Andréfouët Serge, 2023,
"Atolls of Australia: geospatial vector data (MCRMP project)",
https://doi.org/10.23708/JXNMFY, DataSuds


Dataset description
The Millennium Coral Reef Mapping Project provides thematic maps of coral reefs worldwide at geomorphological scale. Maps were created by photo-interpretation of Landsat 7 and Landsat 8 satellite images.

Maps are provided as standard Shapefiles usable in GIS software. The geomorphological classification scheme is hierarchical and includes 5 levels. The GIS products include for each polygon a number of attributes. The 5 level geomorphological attributes are provided (numerical codes or text). The Level 1 corresponds to the differentiation between oceanic and continental reefs. Then from Levels 2 to 5, the higher the level, the more detailed the thematic classification is. Other binary attributes specify for each polygon if it belongs to terrestrial area (LAND attribute), and sedimentary or hard-bottom reef areas (REEF attribute). Examples and more details on the attributes are provided in the references cited. The products distributed here were created by IRD, in their last version.

Shapefiles for 29 atolls of Australia as mapped by the Global coral reef mapping project at geomorphological scale using LANDSAT satellite data (L7 and L8). Global coral reef mapping project at geomorphological scale using LANDSAT satellite data (L7 and L8).

Funded by National Aeronautics and Space Administration, NASA grants NAG5-10908 (University of South Florida, PIs: Franck Muller-Karger and Serge Andréfouët) and CARBON-0000-0257 (NASA, PI: Julie Robinson) from 2001 to 2007. Funded by IRD since 2003 (in kind, PI: Serge Andréfouët).
